#!/usr/bin/env python
from model import model


mdl = model(
        hmode=1,
        wpenalty=0,
        )
mdl.chk_chempot()
