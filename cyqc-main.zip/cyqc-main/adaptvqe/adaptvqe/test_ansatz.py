import pickle
from pqasm import paramCircuits


with open('ansatz.pkle', 'rb') as f:
    data = pickle.load(f)

ansatz = data[0]
breakpoint()
