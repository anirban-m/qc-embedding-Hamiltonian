Noiseless simulator for qubit-adapt-vqe type. 
Check example for model setup and calculations.
