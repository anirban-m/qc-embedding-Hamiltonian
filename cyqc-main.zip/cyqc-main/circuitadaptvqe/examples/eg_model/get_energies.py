# extract the qasm and statevector energies from the log files.
import glob, h5py


results = []
ticks = []
energies_sv = []
for path in ['s10g16', 's12g16', 's14g16', 's16g16']:
    fname = glob.glob(f'./pool_HC/{path}/slurm*')[0]
    results.append([])
    ticks.append([])
    energies_sv.append([])
    with open(fname, 'r') as f:
        for line in f:
            if 'loop energy' in line:
                results[-1].append(float(line.split()[2]))
            if 'Energy_sv' in line:
                ticks[-1].append(len(results[-1]))
                energies_sv[-1].append(float(line.split()[4]))

with h5py.File('energies.h5', 'w') as f:
    f['energies'] = results
    f['energies_sv'] = energies_sv
    f['ticks'] = ticks

