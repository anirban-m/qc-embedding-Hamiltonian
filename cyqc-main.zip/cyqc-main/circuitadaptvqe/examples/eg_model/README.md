get_energies.py,  get_energies3.py: sample scripts to extract energy traces. 

pool_HC: Calculations with Hamiltonian commutetor pool

pool_minimal_complete: CAlculations with minimal complete pool.

subfolder name convention -- sxgy: calculation with shots = 2**x, 
    with exceptoion for shots = 2**y for operator selection 
    from the operator pool.

job.slurm: parallel job submission script. 
