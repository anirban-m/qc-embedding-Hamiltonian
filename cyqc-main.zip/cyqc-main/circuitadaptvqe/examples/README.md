eg_model: series of qasm simjulations of eg_model.

eg_model_ibmQ_Casablanca: eg model calculaition script on IBM haedware.

eg_model_VQE_Adadelta: eg_model qasm simulation with adadelta optimizer.
