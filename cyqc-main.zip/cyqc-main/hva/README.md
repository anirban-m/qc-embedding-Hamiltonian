Hamiltonian variational ansatz

Install using pip install -e ./hva --user

Check example for explanation of model set up and how to run.
