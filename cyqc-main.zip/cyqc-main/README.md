# CyQC: Quantum computing toolset for correlated materials simulations
A collection of codes which implement quantum algorithms for correlated materials simulations. They are developed by the [quantum computing for materials science team](https://scholar.google.com/citations?user=HbS_lmgAAAAJ&hl=en) in Ames Laboratory. 

## Codes in the collection
* `hva`: statevector implementation of variational quantum eigensolver (VQE) with Hamiltonian variational ansatz.
* `adaptvqe`: statevector implementation of qubit-ADAPT-VQE.
* `circuitadaptvqe`: circuit implementation of qubit-ADAPT-VQE for the (Ns=2, Nb=2) eg impurity model.

## Associated publications
* [1] A. Mukherjee, N. F. Berthusen, J. C. Getelina, P. P. Orth, and Y.-X. Yao, Comparative Study of Adaptive Variational Quantum Eigensolvers for Multi-Orbital Impurity Models, [ArXiv:2203.06745 (2022).](https://arxiv.org/abs/2203.06745)
