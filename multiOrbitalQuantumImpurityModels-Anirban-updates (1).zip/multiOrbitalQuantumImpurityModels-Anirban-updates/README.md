# MultiOrbitalQuantumImpurityModels

Data for variational calculations of multi-orbital quantum impurity models