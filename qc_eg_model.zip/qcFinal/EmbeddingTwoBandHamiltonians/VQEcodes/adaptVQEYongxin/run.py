#!/usr/bin/env python

from model import model
from ansatz import ansatz

qmodel = model()
ans = ansatz(qmodel)
ans.additive_optimize()
