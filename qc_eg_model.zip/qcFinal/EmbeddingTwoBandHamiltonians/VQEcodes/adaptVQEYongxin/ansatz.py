# author: Yongxin Yao (yxphysice@gmail.com)
import numpy, h5py
import json
from qiskit.aqua.operators.legacy import op_converter
import scipy.optimize, scipy.linalg, scipy.sparse
from timing import timeit
def warn(*args, **kwargs):
    pass
import warnings
from qiskit.quantum_info import Pauli
from qiskit.aqua.operators import WeightedPauliOperator


Hlist=json.load(open('HinMOrep1.json','r'))['h']
penaltyList=json.load(open('HinMOrep1.json','r'))['ntot']
nume=json.load(open('HinMOrep1.json','r'))['nume']
Hlist=[Hlist[i].split('*') for i in range(len(Hlist))]
qubitH=WeightedPauliOperator([[float(Hlist[i][0]),Pauli(Hlist[i][1])] for i in range(len(Hlist))])
op2list=[penaltyList[i].split('*') for i in range(len(penaltyList))]
op2=WeightedPauliOperator([[float(op2list[i][0]),Pauli(op2list[i][1])] for i in range(len(op2list))])
Hmat=op_converter.to_matrix_operator(qubitH).dense_matrix
w,v=numpy.linalg.eigh(Hmat)
state_g=v[:,59]
print("Eg",w[59])
class spectra_data:
    '''
    data type for more efficient expm calculation.
    store the dense matrix and spectral representation
    '''
    def __init__(self,
            qobj,   # qobj from qutip
            ):
        # save full dense matrix
        self._a = qobj.full()
        # save the spectral representation
        self._w, self._v = numpy.linalg.eigh(self._a)

    def expm(self, alpha):
        # calculate exp(alpha*a)
        return (self._v*numpy.exp(alpha*self._w)).dot(self._v.T.conj())

    def dot(self, b):
        '''
        dot product.
        '''
        return self._a.dot(b)

    def matrix_element(self, v, vp):
        return v.conj().dot(self._a.dot(vp))


class ansatz:
    '''
    define the main procedures of adapt-vqe calculation.
    set up: 1) default referece state of the ansatz.
            2) operator pool
    '''
    def __init__(self,
            model,           # the qubit model
            opdense=True,    # operator in dense matrix format
            ):
        # variational parameters.
        self._params = []
        # list of unitaries in terms of operators and labels
        self._ansatz = [[], []]
        self._opdense = opdense
        self._model = model
        self._nq = model._nsite

        # set reference state
        self.set_ref_state()
        self._state = None
        # generate operator
        self.setup_pool()

    @timeit
    def additive_optimize(self):
        # change the representation of H if necessary.
        if self._opdense:
            self._h = spectra_data(self._model._h)
        else:
            self._h = self._model._h
        # (adaptively) optimize the ansatz to represent the groud state
        # of the model Hamiltonian.
        self.optimize_params()
        print(f"initial cost = {self._cost:.6f}")
        iloop = 0
        while True:
            # one iteration of qubit-adapt-vqe.
            added = self.add_op()
            if not added:
                # reaching convergence.
                break
            self.optimize_params()
            self.update_state()
            print(f"ngates: {self._ngates}")
            print(f"iter {iloop}: cost = {self._cost:.6f}")
            iloop += 1

    @property
    def state(self):
        return self._state

    @property
    def ngates(self):
        return self._ngates[:]

    def get_cost(self):
        '''
        get the value of the cost function (Hamiltonian expectation value).
        '''
        # have the state vector updated.
        self.update_state()
        # expectation value of the Hamiltonian
        res = self._h.matrix_element(self._state, self._state)
        return res.real

    @timeit
    def update_state(self):
        self._state = self.get_state()

    def setup_pool(self):
        '''
        setup pool from pool.inp
        '''
        labels = self._model._incar["pool"]
        self._pool = [[self._model.label2op(s), s] for s in labels]
        self._ngates = [0]*len(self._pool[0][1])
        print(f'pool dimension: {len(self._pool)}')

        if self._opdense:
            # convert to more efficient data structure if needed.
            for i, op in enumerate(self._pool):
                self._pool[i][0] = spectra_data(op[0])

    def set_ref_state(self):
        '''set reference state from ref_state.inp file.
        '''
        ref = self._model._incar["ref_state"]
        # binary literal to int
        nnz = int(ref, 2)
        self._ref_state = numpy.zeros((2**self._nq), dtype=numpy.complex_)
        self._ref_state[nnz] = 1.

    @timeit
    def optimize_params(self):
        if len(self._params) > 0:
            # full reoptimization of the ansatz given the initial point.
            res = scipy.optimize.minimize(fun_cost,
                    self._params,               # starting parameter point
                    args=(self._ansatz[0],      # only need the ansatz
                                                # operators, not the indices.
                            self._ref_state,    # reference state
                            self._h,            # Hamiltonian
                            ),
                    method='BFGS',              # optimizer
                    jac=fun_jac,                # analytical jacobian function
                    )
            if res.success:
                # save parameters and cost.
                self._params = res.x.tolist()
                self._cost = res.fun
            else:
                print(res.message)
        else:
            # no parameters to optimize, directly evaluate.
            self._cost = self.get_cost()

    @timeit
    def add_op(self,
            tol=1.e-6,
            ):
        '''
        adding a initary  in the adapt-vqe.
        '''
        scores = self.get_pool_scores()
        ids = numpy.argsort(abs(scores))
        iadd = ids[-1]
        print("top 3 scores: "+ \
                f"{' '.join(f'{scores[i]:.2e}' for i in ids[-3:])}")
        if len(self._ansatz[1]) > 0  \
                and self._pool[iadd][1] == self._ansatz[1][-1]:
            # no further improvement
            print(f"abort: pauli ops {self._ansatz[1][-1]}" + \
                    f" vs {self._pool[iadd][1]}")
            return False
        elif abs(scores[iadd]) < tol:
            print(f"converge: gradient = {scores[iadd]:.2e} too small.")
            return False
        else:
            self._ansatz[0].append(self._pool[iadd][0])
            # label
            self._ansatz[1].append(self._pool[iadd][1])
            self.update_ngates()
            print(f"op {self._ansatz[1][-1]} appended.")
            self._params.append(0.)
            return True

    def update_ngates(self):
        '''
        update gate counts.
        '''
        label = self._ansatz[1][-1]
        iorder = len(label) - label.count('I')
        self._ngates[iorder-1] += 1

    def get_state(self):
        return get_ansatz_state(self._params,
                        self._ansatz[0],
                        self._ref_state,
                        )

    def get_pool_scores(self):
        '''-0.5j <[h,op]> = im(<h op>)
        '''
        scores = []
        if self._opdense:
            h_vec = self._h.dot(self._state)
        else:
            h_vec = self._h*self._state
        for op in self._pool:
            op = op[0]
            if self._opdense:
                ov = op.dot(self._state)
                zes = numpy.vdot(h_vec, ov)
            else:
                ov = op*self._state
                zes = h_vec.overlap(ov)
            scores.append(zes.imag)
        return numpy.array(scores)

    def save_ansatz(self):
        with h5py.File("ansatz.h5", "w") as f:
            # initial state params
            f["/params"] = self._params_init
            # ansatz operator labels
            f["/ansatz_code"] = self._ansatz[1]
            # ngates
            f["/ngates"] = self._ngates
            # reference state
            f["/ref_state"] = self._ref_state

    def save_state(self, t):
        with h5py.File("state.h5", "w") as f:
            f["t"] = t
            if self._opdense:
                f["state"] = self._state
            else:
                f["state"] = self._statevec.full().reshape(-1)


def fun_cost(params, ansatz, ref_state, h):
    state = get_ansatz_state(params, ansatz, ref_state)
    res = h.matrix_element(state, state)
    print("fidelity",numpy.abs(state@state_g))
    return res.real


def fun_jac(params, ansatz, ref_state, h):
    # - d <var|h|var> / d theta
    np = len(ansatz)
    vec = get_ansatz_state(params, ansatz, ref_state)
    opdense = isinstance(vec, numpy.ndarray)
    # <vec|h
    if opdense:
        h_vec = h.dot(vec)
    else:
        h_vec = h*vec

    jac = []
    state_i = ref_state
    if opdense:
        for i in range(np):
            op = ansatz[i]
            state_i = op.expm(-0.5j*params[i]).dot(state_i)
            state = op.dot(state_i)
            for theta, op in zip(params[i+1:], ansatz[i+1:]):
                state = op.expm(-0.5j*theta).dot(state)
            zes = numpy.vdot(h_vec, state)
            jac.append(zes.imag)
    else:
        for i in range(np):
            opth = -0.5j*params[i]*ansatz[i]
            state_i = opth.expm()*state_i
            state = op*state_i
            for theta, op in zip(params[i+1:], ansatz[i+1:]):
                opth = -0.5j*theta*op
                state = opth.expm()*state
            zes = h_vec.overlap(state)
            jac.append(zes.imag)
    res = numpy.array(jac)
    return res


def get_ansatz_state(params, ansatz, ref_state):
    state = ref_state
    opdense = isinstance(state, numpy.ndarray)
    for theta, op in zip(params, ansatz):
        if opdense:
            opth_expm = op.expm(-0.5j*theta)
            state = opth_expm.dot(state)
        else:
            opth = -0.5j*theta*op
            state = opth.expm()*state
    return state
