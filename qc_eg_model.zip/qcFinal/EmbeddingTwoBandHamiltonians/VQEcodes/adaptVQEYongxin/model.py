# author: Yongxin Yao (yxphysice@gmail.com)
import json
from qutip import qeye, sigmax, sigmay, sigmaz, tensor


class model:
    '''
    Base class. defines some common functions for various spin models.
    '''
    def __init__(self,
            wpenalty=10.,  # prefactor of pentalty terms
            ):
        '''
        read h.inp and set up the Hamiltonian.
        '''
        self._wpenalty = wpenalty
        self.load_incar()
        self.setup_h()
        self.add_npenalty()

    def load_incar(self):
        self._incar = json.load(open("incar", "r"))

    def setup_h(self):
        hs_list = self._incar["h"]
        print(f'Hamiltonian terms: {len(hs_list)}')
        self._nsite = len(hs_list[0].split("*")[1])
        self.set_ops()
        self._h = self.coeflabels2op(hs_list)

    def add_npenalty(self):
        '''add (ntot_op -n_e)**2 if ntot.inp is present.
        '''
        if "ntot" in self._incar:
            ns_list = self._incar["ntot"]
            n_op = self.coeflabels2op(ns_list)
            nume = self._incar["nume"]
            print(n_op-nume)
            self._h += self._wpenalty*(n_op - nume)**2

    def coeflabels2op(self, clabels):
        op = 0
        for clabel in clabels:
            coef, label = clabel.split("*")
            op1 = self.label2op(label)
            op += op1*float(coef)
        return op

    def label2op(self, label):
        op = 1
        for i, s in enumerate(label):
            if s in ["X", "Y", "Z"]:
                op *= self._ops[s][i]
        return op

    def set_ops(self):
        '''
        set up site-wise sx, sy, sz operators.
        '''
        self._ops = {}
        self._ops["X"], self._ops["Y"], self._ops["Z"] = \
                get_sxyz_ops(self._nsite)

    def get_h(self):
        '''
        get Hamiltonian.
        '''
        return self._h



def get_sxyz_ops(nsite):
    '''
    set up site-wise sx, sy, sz operators.
    '''
    si = qeye(2)
    sx = sigmax()
    sy = sigmay()
    sz = sigmaz()
    sx_list = []
    sy_list = []
    sz_list = []

    op_list = [si for i in range(nsite)]
    for i in range(nsite):
        op_list[i] = sx
        sx_list.append(tensor(op_list))
        op_list[i] = sy
        sy_list.append(tensor(op_list))
        op_list[i] = sz
        sz_list.append(tensor(op_list))
        # reset
        op_list[i] = si
    return [sx_list, sy_list, sz_list]
