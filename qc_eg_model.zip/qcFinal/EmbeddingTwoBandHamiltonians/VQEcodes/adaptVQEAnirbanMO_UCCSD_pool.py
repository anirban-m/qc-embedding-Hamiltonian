def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
import numpy
import copy
from skquant.opt import minimize
import ipyparallel as ipp
from qiskit.quantum_info import Pauli
from qiskit import QuantumCircuit,execute
from qiskit.chemistry import FermionicOperator
from qiskit.aqua.operators.legacy import op_converter
from qiskit import Aer
from joblib import Parallel,delayed
from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.chemistry.components.variational_forms import UCCSD
import scipy
import json
import time
c =ipp.Client()
num_qubits=8
c.ids
v1 = c.load_balanced_view([0,1,2,3,4,5,6,7])
def compute_gradient(data):
    circLast,Op=data
    circ1=circLast.copy()
    circ2=circLast.copy()
    state1=execute(circ1,backend,shots=1024).result().get_statevector() 
    E1=(numpy.conjugate(state1)@Hmat@state1).real
    label=Op.paulis[0][1].to_label()
    Label=numpy.array(list(label))
    qubits_to_act_on=list(numpy.where(Label!='I')[0])
    substring=''.join(list(Label[qubits_to_act_on]))
    UnitaryMat=Pauli.from_label(substring).to_matrix()
    UnitaryMatrix1=numpy.cos(0.01)*numpy.eye(2**len(qubits_to_act_on))-1j*numpy.sin(0.01)*UnitaryMat
    UnitaryMatrix2=numpy.cos(0.01)*numpy.eye(2**len(qubits_to_act_on))+1j*numpy.sin(0.01)*UnitaryMat
    circ1.unitary(UnitaryMatrix1,qubits_to_act_on[::-1],label=label)
    circ2.unitary(UnitaryMatrix2,qubits_to_act_on[::-1],label=label)
    state1=execute(circ1,backend,shots=1024).result().get_statevector() 
    state2=execute(circ2,backend,shots=1024).result().get_statevector() 
    E1=(numpy.conjugate(state1)@Hmat@state1).real
    E2=(numpy.conjugate(state2)@Hmat@state2).real
    grad=(E1-E2)/0.02
    return grad
def qubit_UCCSD_pool(*args,**kwargs):
    circ=QuantumCircuit(8)
    circ.x(0)
    circ.x(1)
    circ.x(4)
    circ.x(5)
    var_form_base=UCCSD(8,num_particles=4, initial_state=circ,qubit_mapping='jordan_wigner',two_qubit_reduction=False)
    var_form_base.manage_hopping_operators()
    fer_pool_UCCSD=var_form_base.excitation_pool
    qubit_pool_UCCSD=[]
    for i in range(len(fer_pool_UCCSD)):
        for j in range(len(fer_pool_UCCSD[i].paulis)):
            qubit_pool_UCCSD.append(WeightedPauliOperator([[1j,fer_pool_UCCSD[i].paulis[j][1]]]))
    return numpy.array(qubit_pool_UCCSD)
def Energy(params):
    circ=ansatz_circuit(PaulisAndMats,params) #var_form_base.construct_circuit(parameters=params) 
    state=execute(circ,backend,shots=1024).result().get_statevector() 
    E=(numpy.conjugate(state)@Hmat@state).real
#     with open('paramsForQubitAdapt_eg_model_MO.txt','+a') as f:
#         Str=["{:0.16f}".format(params[i].real) for i in range(len(params))]
#         print('['+','.join(Str)+']'+'#'+"{:0.16f}".format(E.real),file=f)
    return E
def qubitOp(h1,h2):
    qubit_op=FermionicOperator(h1,h2).mapping('jordan_wigner')
    return qubit_op
#Ansatz Circuit Construction
def ref_state(*args,**kwargs):
    init_circ=QuantumCircuit(num_qubits)
    for i in range(num_sites//2):
        init_circ.x(i)
        init_circ.x(i+num_sites)
    return init_circ    
def PauliStringToMatrix(Label):
    Label1=numpy.array(list(Label))
    LabelInds=numpy.where(Label1!='I')[0]
    substring=''.join(list(Label1[LabelInds]))
    UnitaryMat=Pauli(substring).to_matrix()
    return [UnitaryMat,LabelInds]
def UnitaryMatrixForm(data):
    import numpy
    PaulisAndMats,params,ind=data
    Label=PaulisAndMats[ind][0]
    UnitaryMat,qubits_to_act_on=PaulisAndMats[ind][1]
    UnitaryMatrix=numpy.cos(params[ind])*numpy.eye(2**len(qubits_to_act_on))-1j*numpy.sin(params[ind])*UnitaryMat
    return [UnitaryMatrix,qubits_to_act_on[::-1],Label]
def ansatz_circuit(PaulisAndMats,params):
    circ=ref_state()
    if(len(PaulisAndMats)!=0):
        inp_data=[(PaulisAndMats,params,i) for i in range(len(params))]
        #result = v1.map_async(UnitaryMatrixForm, inp_data)
        #UnitaryMatArr=result.get()
        UnitaryMatArr=list(map(UnitaryMatrixForm,inp_data))
        for i in range(len(UnitaryMatArr)):
            circ.unitary(UnitaryMatArr[i][0],list(UnitaryMatArr[i][1]),label=UnitaryMatArr[i][2])
        v1.purge_results('all')
        del inp_data    
        del UnitaryMatArr
    return circ     
U=7
num_qubits=8
num_sites=num_qubits//2
#Hamiltonian for eg Model in MO basis
#Setting up MO Hamiltonian
#Hamiltonian for eg Model in MO basis
#Setting up MO Hamiltonian
Hlist=json.load(open('../7/FinalDataFiles/adaptVQE-opt-SMO-MO-Hamiltonian/HinMOrep1.json','r'))['h']
penaltyList=json.load(open('../7/FinalDataFiles/adaptVQE-opt-SMO-MO-Hamiltonian/HinMOrep1.json','r'))['ntot']
nume=json.load(open('../7/FinalDataFiles/adaptVQE-opt-SMO-MO-Hamiltonian/HinMOrep1.json','r'))['nume']
Hlist=[Hlist[i].split('*') for i in range(len(Hlist))]
qubitH=WeightedPauliOperator([[float(Hlist[i][0]),Pauli.from_label(Hlist[i][1])] for i in range(len(Hlist))])
op2list=[penaltyList[i].split('*') for i in range(len(penaltyList))]
op2=WeightedPauliOperator([[float(op2list[i][0]),Pauli.from_label(op2list[i][1])] for i in range(len(op2list))])
Num=op_converter.to_matrix_operator(op2).dense_matrix
with open('../chem_pot_for_Half_Fill.txt','r') as f:
        lines=f.readlines()[1:]
        for line in lines:
            elems=line.split()
            if int(elems[0])==U:
                muHalf=float(elems[1]) #Chem Pot for a given Hubbard U
chem_pot=numpy.zeros((2*num_sites,2*num_sites))
for i in range(len(chem_pot)):
    chem_pot[i][i]=-muHalf
qubit_chem_pot=qubitOp(chem_pot,numpy.zeros((8,8,8,8)))
qubitH=qubitH.add(qubit_chem_pot)
Hmat=op_converter.to_matrix_operator(qubitH).dense_matrix
w,v=numpy.linalg.eigh(Hmat)
Eg=w[0]
print("exact GS E",Eg)
#qubit UCCSD pool
pool_UCCSD_labels=["IIIIIXZY","IIIIIYZX","IIIIXZZY","IIIIYZZX","IIIIIXYI","IIIIIYXI","IIIIXZYI","IIIIYZXI","IXZYIIII","IYZXIIII","XZZYIIII",
        "YZZXIIII","IXYIIIII","IYXIIIII","XZYIIIII","YZXIIIII","IXZYIYZY","IYZYIXZY","IXZXIXZY","IYZXIYZY","IXZYIXZX","IYZYIYZX","IXZXIYZX",
        "IYZXIXZX","XZZYYZZY","YZZYXZZY","XZZXXZZY","YZZXYZZY","XZZYXZZX","YZZYYZZX","XZZXYZZX","YZZXXZZX","IXYIIYYI","IYYIIXYI","IXXIIXYI",
        "IYXIIYYI","IXYIIXXI","IYYIIYXI","IXXIIYXI","IYXIIXXI","XZYIYZYI","YZYIXZYI","XZXIXZYI","YZXIYZYI","XZYIXZXI","YZYIYZXI","XZXIYZXI",
        "YZXIXZXI","IIIIXXXY","IIIIYYXY","IIIIXYYY","IIIIYXYY","IIIIXYXX","IIIIYXXX","IIIIXXYX","IIIIYYYX","XXXYIIII","YYXYIIII","XYYYIIII",
        "YXYYIIII","XYXXIIII","YXXXIIII","XXYXIIII","YYYXIIII"]#qubit_UCCSD_pool()
pool_UCCSD=[WeightedPauliOperator([[1j,Pauli(label)]]) for label in pool_UCCSD_labels]
print("pool size",len(pool_UCCSD))
def fun_jac(params):
    setofParams1=[numpy.array(params)+numpy.array([0]*i+[0.001]+[0]*(len(params)-i-1)) for i in range(len(params))]
    setofParams2=[numpy.array(params)+numpy.array([0]*i+[-0.001]+[0]*(len(params)-i-1)) for i in range(len(params))]
    EnergySet1=list(map(Energy,setofParams1))
    EnergySet2=list(map(Energy,setofParams2))
    jac=(numpy.array(EnergySet1)-numpy.array(EnergySet2))/0.002
    return jac
def SMO(cost,params,runs=20,tol=1e-4,save_opt_steps=False):
    index=1
    conv_err=1000
    def E_landscape(ind,ang,cost,params):
        params1=copy.deepcopy(params)
        params1[ind]=params1[ind]+ang #ang
        #circ=var_form_base.construct_circuit(parameters=params1)
        E=cost(params1)
        return E.real
    def determine_unknowns(E,cost,params,ind):
        L1=E#_landscape(ind,0,params,Hmat)
        L2=E_landscape(ind,numpy.pi/4.,cost,params)
        L3=E_landscape(ind,-numpy.pi/4.,cost,params)
        ratio=(L3-L2)/(2*L1-L2-L3)
        a3=(L2+L3)/2.
        a2=2*params[ind]-numpy.arctan(ratio)
        a1=(L1-a3)/numpy.cos(numpy.arctan(ratio))
        return a1,a2,a3
    def update(E,cost,params,ind):
        a1,a2,a3=determine_unknowns(E,cost,params,ind)
        thetaStar=a2/2.+numpy.pi/2. if a1>0 else a2/2.
        newParams=copy.deepcopy(params)
        newParams[ind]=thetaStar
        updEnergy=a3-a1 if a1>0 else a3+a1
        return newParams,updEnergy.real
    while conv_err>tol and index<runs:
        print("looped "+str(index)+" times")
        Eold=cost(params)
        init=0
        for i in range(len(params)):#[::-1][0:1]:
            #first run sequential minimial optimization (SMO)  for a given multiqubit operator using 
            #exact analytical form for cost function
            if init==0:
                E=Eold
            ind=i
            params,E=update(E,cost,params,ind)
            if save_opt_steps==True:
                with open('paramsForQubitAdapt_eg_model_MO.txt','a') as f:
                    Str=["{:0.16f}".format(params[i].real) for i in range(len(params))]
                    print('['+','.join(Str)+']'+'#'+"{:0.16f}".format(E.real),file=f)
            else:
                continue
            init=init+1  
        conv_err=Eold-E
        print("inner loop error",conv_err)
        index=index+1
    return params,E 
error=1000
params=[]
PaulisAndMats=[]
# with open('paramsForQubitAdapt_eg_model_MO.txt','r') as f:
#     lines=f.readlines()
#     for i in range(len(lines)):
#         if lines[i][0]=='l':
#             label=lines[i].split('-')[1][1:-1]
#             PaulisAndMats.append([label,PauliStringToMatrix(label)])
#     params=eval(lines[-1].split('#')[0])        
EnergyArr=[]
ExcOps=[]
counts=35
count=1
ti=time.time()
circLast=ansatz_circuit(PaulisAndMats,params) 
backend=Aer.get_backend('statevector_simulator')
for i in range(counts):
    grads=Parallel(n_jobs=7,verbose=2)(delayed(compute_gradient)((circLast,pool_UCCSD[i])) for i in range(len(pool_UCCSD)))
    ind=numpy.argsort(numpy.abs(grads))[-1]
    print("max. grad",grads[ind])
    PauliOp=pool_UCCSD[ind]
    ExcOps.append(PauliOp.paulis[0][1].to_label())
    print("chosen Op",ExcOps[-1])
    with open('paramsForQubitAdapt_eg_model_MO.txt','a') as f:
        print("label-",ExcOps[-1],file=f)
    params.append(0.0)
    PaulisAndMats.append([ExcOps[-1],PauliStringToMatrix(ExcOps[-1])])
    #construct circuit for estimating Hamiltonian
    params,E=SMO(Energy,params,tol=1e-5,runs=40,save_opt_steps=True)#scipy.optimize.minimize(Energy,params,method='L-BFGS-B')#,jac=fun_jac)
    EnergyArr.append(Energy(params))
    print("Energy",Energy(params))
    print("num. of parameters", len(params))
    print("time elapsed",time.time()-ti)    
    error=EnergyArr[-1]-Eg
    circLast=ansatz_circuit(PaulisAndMats,params)   