from qiskit.aqua.algorithms import VQE, ExactEigensolver
import matplotlib.pyplot as plt
#%matplotlib inline
import numpy as np
from qiskit.chemistry.components.variational_forms import UCCSD
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.chemistry.components.initial_states import HartreeFock
from qiskit.aqua.algorithms import NumPyMinimumEigensolver
from qiskit.chemistry.core import Hamiltonian, TransformationType, QubitMappingType
from qiskit.aqua.components.optimizers import COBYLA, SPSA, SLSQP
from qiskit import IBMQ, BasicAer, Aer
from qiskit.chemistry.drivers import PySCFDriver, UnitsType, HFMethodType, InitialGuess
from qiskit.chemistry import FermionicOperator
from qiskit import IBMQ
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
import sys


def run(r):
    driver = PySCFDriver(
            atom=(
                    f'Li 0 0 0;'
                    f'H {r} 0 0'
                    ),
            unit=UnitsType.ANGSTROM,
            charge=0,
            spin=0,
            basis='sto3g',
            max_cycle=200,
            )
    molecule = driver.run()
    print("hf energy:", molecule.hf_energy - molecule.nuclear_repulsion_energy)
    num_particles = molecule.num_alpha + molecule.num_beta
    num_spin_orbitals = molecule.num_orbitals * 2

    core = Hamiltonian(transformation=TransformationType.FULL,
                       qubit_mapping=QubitMappingType.JORDAN_WIGNER,
                       two_qubit_reduction=True,
                       freeze_core=False,
                       orbital_reduction=None,
                       z2symmetry_reduction='auto')
    qubit_op, aux_ops = core.run(molecule)
    print(qubit_op)
    print("tapering:", core.molecule_info[core.INFO_Z2SYMMETRIES])
    print("num_qubits:", qubit_op.num_qubits)
    h = qubit_op.to_opflow().to_spmatrix().todense()
    w, v = np.linalg.eigh(h)
    print(f"lowest states: {w[:2]}")



if __name__ == "__main__":
    run(1.6)
