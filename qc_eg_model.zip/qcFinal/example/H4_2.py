from qiskit.aqua.algorithms import VQE, ExactEigensolver
from qiskit.chemistry import FermionicOperator
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.chemistry.drivers import PySCFDriver, UnitsType
from qiskit.aqua.components.optimizers import SPSA
from qiskit import IBMQ, Aer
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
from qiskit.aqua.operators.weighted_pauli_operator import Z2Symmetries
import h5py, numpy
from pyscf import gto


driver = PySCFDriver(
        atom=('H -0.3000 .0 -0.3000;'
                'H -0.3000 .0 0.3000;'
                'H 0.3000 .0 0.3000;'
                'H 0.3000 .0 -0.3000'),
        unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g')

molecule = driver.run()
print(f"nuclear repulsion energy = {molecule.nuclear_repulsion_energy}")
num_particles = molecule.num_alpha + molecule.num_beta
num_spin_orbitals = molecule.num_orbitals * 2
print(f"num_spin_orbitals: {num_spin_orbitals}")

fermiOp = FermionicOperator(h1=molecule.one_body_integrals,
        h2=molecule.two_body_integrals)
qubitOp = fermiOp.mapping(map_type='bravyi_kitaev')
qubitOp = Z2Symmetries.two_qubit_reduction(qubitOp, num_particles)
print(qubitOp.print_details())

edsolver = ExactEigensolver(qubitOp)
exact_solution = edsolver.run()

print("Exact Result:", exact_solution['energy'])
print("hf energy:", molecule.hf_energy-molecule.nuclear_repulsion_energy)
