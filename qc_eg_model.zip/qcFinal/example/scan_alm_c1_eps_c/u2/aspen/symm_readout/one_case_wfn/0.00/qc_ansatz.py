from pyquil.quil import Program
from pyquil.gates import X

niter = 100  # max iter for vqe optimization.
cq = [0, 1]
ref_states = [
        [
        Program(X(cq[1]))   # 01
        ],
        ]

ansatz_params = [
        [0],
        ]

ansatz_ops = [
        [
        "1*Y0X1"
        ],
        ]
