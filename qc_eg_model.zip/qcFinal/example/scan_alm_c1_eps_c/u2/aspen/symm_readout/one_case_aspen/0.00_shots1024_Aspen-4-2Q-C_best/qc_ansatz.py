from pyquil.quil import Program
from pyquil.gates import X
from pyquil.experiment._symmetrization import SymmetrizationLevel
from pyquil.experiment._calibration import CalibrationMethod


niter = 10  # max iter for vqe optimization.
#qc = 'Aspen-7-2Q-C'; cq = [21, 36]
#qc = 'Aspen-4-2Q-H'; cq = [1, 2]
qc = 'Aspen-4-2Q-C'; cq = [14, 15]
# qc = '2q-noisy-qvm'; cq = [0, 1]
shots = 2**10
verbose = False
symmetrization = SymmetrizationLevel.EXHAUSTIVE
calibration = CalibrationMethod.PLUS_EIGENSTATE
# ref states
ref_states = [
        [
        Program(X(cq[1]))   # 01
        ],
        ]
# ref_bitstrings should be consistent with ref_states
ref_bitstrings = [
        [
        "01",
        ]
        ]
# the ansatz
ansatz_params = [
        [0],
        ]

ansatz_ops = [
        [
        "1*Y0X1"
        ],
        ]
