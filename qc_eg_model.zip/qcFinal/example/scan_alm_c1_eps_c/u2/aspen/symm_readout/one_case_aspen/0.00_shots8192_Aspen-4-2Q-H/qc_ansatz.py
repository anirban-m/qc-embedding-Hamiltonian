from pyquil.quil import Program
from pyquil.gates import X
from pyquil.experiment._symmetrization import SymmetrizationLevel
from pyquil.experiment._calibration import CalibrationMethod


niter = 10  # max iter for vqe optimization.
#qc = 'Aspen-7-2Q-C'
qc = 'Aspen-4-2Q-H'
# qc = '2q-noisy-qvm'
cq = [21, 36]
shots = 2**13
verbose = False
symmetrization = SymmetrizationLevel.EXHAUSTIVE
calibration = CalibrationMethod.PLUS_EIGENSTATE
# ref states
ref_states = [
        [
        Program(X(cq[1]))   # 01
        ],
        ]
# ref_bitstrings should be consistent with ref_states
ref_bitstrings = [
        [
        "01",
        ]
        ]
# the ansatz
ansatz_params = [
        [0],
        ]

ansatz_ops = [
        [
        "1*Y0X1"
        ],
        ]
