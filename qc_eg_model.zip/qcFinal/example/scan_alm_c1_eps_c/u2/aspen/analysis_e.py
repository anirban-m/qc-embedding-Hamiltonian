import numpy, os

num_samples = 10
ec_range = numpy.arange(0.0, 1.3, 0.1)
emean_list = []
estd_ist = []
for ec in ec_range:
    path = f"{ec:.2f}"
    e_list = []
    os.chdir(path)
    with open("Gutz.log", "r") as f:
        for line in f:
            if "e_total_model" in line:
                e = float(line.split("=")[1])
                e_list.append(e)
    if len(e_list) > num_samples:
        e_list = e_list[-num_samples:]
    emean_list.append(numpy.mean(e_list))
    estd_ist.append(numpy.std(e_list))
    os.chdir("..")

data = numpy.array([ec_range, emean_list, estd_ist]).T
numpy.savetxt("stat.dat", data, fmt="%.5f", delimiter="  ")
