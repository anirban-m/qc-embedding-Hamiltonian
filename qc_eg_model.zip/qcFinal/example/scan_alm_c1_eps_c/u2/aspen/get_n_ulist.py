import numpy, os

path = "try_aspen4_chosen"


u_list = numpy.arange(0.0, 1.3, 0.1)
z_list = []

for u in u_list:
    folder = f"{u:.2f}"
    os.chdir(f"./{path}/{folder}")
    with open("Gutz.log", "r") as f:
        lread = False
        for line in f:
            if "imp=  1 eigen values of         z" in line:
                lread = True
            elif lread:
                z = float(line.split()[0])
                lread = False
    z_list.append(z)
    os.chdir("../..")

numpy.savetxt("nlist.dat", z_list, fmt="%.4f")
