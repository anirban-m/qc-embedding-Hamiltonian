import matplotlib.pyplot as plt
import numpy


data_ed = numpy.loadtxt("ed.dat").T
data_sv = numpy.loadtxt("uccsd_statevector.dat").T
data_qm = numpy.loadtxt("uccsd_qasm.dat").T
data_ex = numpy.loadtxt("uccsd_qsam_essex.dat").T
data_as = numpy.loadtxt("uccsd_aspen.dat").T
data_hf = numpy.loadtxt("hf.dat").T

plt.figure()
plt.subplot(221)
plt.plot(data_ed[0], data_ed[1], 'o', label="ed")
plt.plot(data_sv[0], data_sv[1], 'h', label="ucc-statevector")
plt.plot(data_qm[0], data_qm[1], '+', label="ucc-qasm")
plt.plot(data_hf[0], data_hf[1], 'x', label="ucc-hf")
plt.plot(data_as[0], data_as[1], '*', label="ucc-aspen")
plt.legend()
plt.xlabel("$\epsilon_{c}$/D")
plt.ylabel("energy/D")
plt.axvline(0.45, ls='--')
plt.axvline(2.65, ls='--')

plt.subplot(222)
plt.plot(data_ed[0], data_ed[2], 'o', label="ed")
plt.plot(data_sv[0], data_sv[2], 'h', label="ucc-statevector")
plt.plot(data_qm[0], data_qm[2], '+', label="ucc-qasm")
plt.plot(data_hf[0], data_hf[2], 'x', label="ucc-hf")
plt.plot(data_as[0], data_as[2], '*', label="ucc-aspen")
plt.xlabel("$\epsilon_{c}$/D")
plt.ylabel("$n_e$/D")
plt.axvline(0.45, ls='--')
plt.axvline(2.65, ls='--')

plt.subplot(223)
plt.plot(data_ed[0], data_ed[3], 'o', label="ed")
plt.plot(data_sv[0], data_sv[3], 'h', label="ucc-statevector")
plt.plot(data_qm[0], data_qm[3], '+', label="ucc-qasm")
plt.plot(data_hf[0], data_hf[3], 'x', label="ucc-hf")
plt.plot(data_as[0], data_as[3], '*', label="ucc-aspen")
plt.xlabel("$\epsilon_{c}$/D")
plt.ylabel("$Z$/D")
plt.axvline(0.45, ls='--')
plt.axvline(2.65, ls='--')

plt.tight_layout()
plt.show()

