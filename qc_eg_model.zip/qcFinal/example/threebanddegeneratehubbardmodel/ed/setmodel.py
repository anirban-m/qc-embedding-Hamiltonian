from pygrisb.model.mbandhubbardsemicir import gutz_model_setup


gutz_model_setup(
        norb=3,
        u=4,
        j=0.3,
        iembeddiag=-2,
        num_e=3.,
        )
