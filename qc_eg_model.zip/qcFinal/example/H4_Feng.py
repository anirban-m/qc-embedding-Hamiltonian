from qiskit.aqua.algorithms import VQE, ExactEigensolver
import matplotlib.pyplot as plt
#%matplotlib inline
import numpy as np
from qiskit.chemistry.components.variational_forms import UCCSD
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.chemistry.components.initial_states import HartreeFock
from qiskit.aqua.components.optimizers import COBYLA, SPSA, SLSQP
from qiskit import IBMQ, BasicAer, Aer
from qiskit.chemistry.drivers import PySCFDriver, UnitsType, HFMethodType, InitialGuess
from qiskit.chemistry import FermionicOperator
from qiskit import IBMQ
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
import sys


def get_qubit_op(dist):
    d = dist/2
    #driver = PySCFDriver(atom='H {} .0 {}; H {} .0 {}; H {} .0 {}; H {} .0 {}'.format(-d,-d,-d,d,d,d,d,-d),
    #    unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g',
    #    hf_method=HFMethodType.RHF, init_guess=InitialGuess.CHKFILE,
    #    chkfile = 'chk_h4.h5')
    driver = PySCFDriver(atom='H {} .0 {}; H {} .0 {}; H {} .0 {}; H {} .0 {}'.format(-d,-d,-d,d,d,d,d,-d),
        unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g',
        hf_method=HFMethodType.RHF)
    molecule = driver.run()
    repulsion_energy = molecule.nuclear_repulsion_energy
    num_particles = molecule.num_alpha + molecule.num_beta
    num_spin_orbitals = molecule.num_orbitals * 2
    ferOp = FermionicOperator(h1=molecule.one_body_integrals, h2=molecule.two_body_integrals)
    sOp = ferOp.total_angular_momentum().mapping(map_type='jordan_wigner')
    qubitOp = ferOp.mapping(map_type='jordan_wigner', threshold=0.00000001)
    shift = repulsion_energy
    return qubitOp, sOp, num_particles, num_spin_orbitals, shift


distances = [0.7]
for dist in distances:
     qubitOp, sOp, num_particles, num_spin_orbitals, shift = get_qubit_op(dist)
     s_mat = ExactEigensolver(sOp)._operator.matrix.toarray()
     result = ExactEigensolver(qubitOp).run()
     exact_energy = result['energy'] + shift
     ev = result['eigvecs'][0]
     mat = ExactEigensolver(qubitOp)._operator.matrix.toarray()
     w,v = np.linalg.eig(mat)
     angmom = []
     for iv in range(len(mat)):
         ev = v[:,iv]
         angmom.append((w[iv].real+shift,np.vdot(ev,np.dot(s_mat,ev)).real))
     angmom.sort(key=lambda s: s[0])
     for s in angmom:
         print(s)
