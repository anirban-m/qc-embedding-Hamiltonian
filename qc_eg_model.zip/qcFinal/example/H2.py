from qiskit.aqua.algorithms import VQE, ExactEigensolver
from qiskit.chemistry import FermionicOperator
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.chemistry.drivers import PySCFDriver, UnitsType
from qiskit.aqua.components.optimizers import SPSA
from qiskit import IBMQ, Aer
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
from qiskit.aqua.operators.weighted_pauli_operator import Z2Symmetries
import h5py, numpy
from pyscf import gto


driver = PySCFDriver(atom='H .0 .0 -0.3625; H .0 .0 0.3625',
        unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g')

molecule = driver.run()
num_particles = molecule.num_alpha + molecule.num_beta

qubitOp = FermionicOperator(h1=molecule.one_body_integrals,
        h2=molecule.two_body_integrals).mapping(map_type='parity')

with h5py.File("H2.h5", "w") as f:
    f["h1"] = molecule.one_body_integrals
    f["h2"] = molecule.two_body_integrals

qubitOp = Z2Symmetries.two_qubit_reduction(qubitOp, num_particles)

provider = IBMQ.load_account()
backend = Aer.get_backend("qasm_simulator")

backends = provider.backends()
print(backends)

# sensitive to device noise model.
#device = provider.get_backend("ibmq_16_melbourne")
device = provider.get_backend("ibmqx2")
coupling_map = device.configuration().coupling_map
noise_model = noise.device.basic_device_noise_model(device.properties())
quantum_instance = QuantumInstance(backend=backend, shots=1000,
        noise_model=noise_model,
        coupling_map=coupling_map,
        measurement_error_mitigation_cls=CompleteMeasFitter,
        cals_matrix_refresh_period=30,)

exact_solution = ExactEigensolver(qubitOp).run()
print("Exact Result:", exact_solution['energy'])

optimizer = SPSA(max_trials=100)
var_form = RYRZ(qubitOp.num_qubits, depth=1, entanglement="linear")
vqe = VQE(qubitOp, var_form, optimizer=optimizer,
        operator_mode="grouped_paulis")
ret = vqe.run(quantum_instance)
print("VQE Result:", ret['energy'])
