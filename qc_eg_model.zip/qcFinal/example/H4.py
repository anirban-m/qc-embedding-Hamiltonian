from qiskit.aqua.algorithms import VQE, ExactEigensolver
from qiskit.chemistry import FermionicOperator
from qiskit.chemistry.aqua_extensions.components.variational_forms import UCCSD
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.chemistry.drivers import PySCFDriver, UnitsType
from qiskit.chemistry.aqua_extensions.components.initial_states import HartreeFock
from qiskit.aqua.components.optimizers import SPSA
from qiskit import IBMQ, Aer
from qiskit.aqua.components.variational_forms import RYRZ
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
from qiskit.aqua.operators.weighted_pauli_operator import Z2Symmetries
import h5py, numpy
from pyscf import gto


driver = PySCFDriver(atom='H -0.3000 .0 -0.3000; H -0.3000 .0 0.3000; H 0.3000 .0 0.3000; H 0.3000 .0 -0.3000',
        unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g')

molecule = driver.run()
print(f"nuclear repulsion energy = {molecule.nuclear_repulsion_energy}")
num_particles = molecule.num_alpha + molecule.num_beta
num_spin_orbitals = molecule.num_orbitals * 2
print(f"num_spin_orbitals: {num_spin_orbitals}")

fermiOp = FermionicOperator(h1=molecule.one_body_integrals,
        h2=molecule.two_body_integrals)
qubitOp = fermiOp.mapping(map_type='parity')

qubitOp = Z2Symmetries.two_qubit_reduction(qubitOp, num_particles)

sOp = fermiOp.total_angular_momentum().mapping(map_type='parity')
sOp = Z2Symmetries.two_qubit_reduction(sOp, num_particles)
nOp = fermiOp.total_particle_number().mapping(map_type='parity')
nOp = Z2Symmetries.two_qubit_reduction(nOp, num_particles)

provider = IBMQ.load_account()
backend = Aer.get_backend("qasm_simulator")

#backends = provider.backends()
#print(backends)

# sensitive to device noise model.
device = provider.get_backend("ibmq_16_melbourne")
#device = provider.get_backend("ibmqx2")
coupling_map = device.configuration().coupling_map
noise_model = noise.device.basic_device_noise_model(device.properties())
quantum_instance = QuantumInstance(backend=backend, shots=1024,
        noise_model=noise_model,
        coupling_map=coupling_map,
        #measurement_error_mitigation_cls=CompleteMeasFitter,
        measurement_error_mitigation_cls=None,
        cals_matrix_refresh_period=30,)

edsolver = ExactEigensolver(qubitOp)
exact_solution = edsolver.run()
print("Exact Result:", exact_solution['energy'])
print("hf energy:", molecule.hf_energy-molecule.nuclear_repulsion_energy)
#print(exact_solution['eigvecs'])

mat = edsolver._operator.matrix.toarray()
print(mat.diagonal()[9])
w, v = numpy.linalg.eigh(mat)
print(w[:4])
print(v[:,0].dot(mat).dot(v[:,0].T.conj()))


s_mat = ExactEigensolver(sOp)._operator.matrix.toarray()
print(v[:,0].dot(s_mat).dot(v[:,0].T.conj()))
quit()



optimizer = SPSA(max_trials=100)
#var_form = RYRZ(qubitOp.num_qubits, depth=1, entanglement="linear")
initial_state = HartreeFock(
    qubitOp.num_qubits,
    num_spin_orbitals,
    num_particles,
    'parity'
)
print(initial_state.bitstr)

# Original hartree fock state is |001001>(F,F,T,F,F,T), change it to
# |001011> (F,F,T,F,T,T)
