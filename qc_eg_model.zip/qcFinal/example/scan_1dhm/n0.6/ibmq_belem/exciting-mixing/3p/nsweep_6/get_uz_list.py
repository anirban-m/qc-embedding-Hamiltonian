import numpy, os

path = "./"


u_list = numpy.arange(0.0, 4.1, 0.5)
z_list = []

for u in u_list:
    folder = f"{u:.2f}"
    os.chdir(f"./{path}/{folder}")
    with open("Gutz.log", "r") as f:
        lread = False
        for line in f:
            if "imp=  1 eigen values of         z" in line:
                lread = True
            elif lread:
                z = float(line.split()[0])
                lread = False
    z_list.append(z)
    os.chdir("..")

numpy.savetxt("zlist.dat", numpy.asarray([u_list, z_list]).T, fmt="%.4f")

