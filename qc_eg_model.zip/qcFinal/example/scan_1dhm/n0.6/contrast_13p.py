import h5py, numpy
import matplotlib.pyplot as plt


us_list = []
zs_list = []
for path in ['state_vector/3pansatz/hybrd/',
        'state_vector/1pansatza/',
        'qasm/excitingmxing_sininrerpolate_1p/',
        'ibmq_belem/exciting-mixing/1p/']:
    with h5py.File(f"{path}/result.h5", "r") as f:
        us_list.append(f["/u_list"][()])
        zs_list.append(f["/z_list"][()])
uzlist3pqasm = numpy.loadtxt("qasm/3p/zlist.dat").T
uzlist3pnoise = numpy.loadtxt("ibmq_belem/exciting-mixing/3p/zlist.dat").T

plt.plot(us_list[0], zs_list[0], label='3p-ansatz-sv')
plt.plot(us_list[1], zs_list[1], label='1p-ansatz-sv')
plt.plot(us_list[2], zs_list[2], 'o', label='1p-ansatz-qasm')
plt.plot(uzlist3pqasm[0], uzlist3pqasm[1], 'd', label='3p-ansatz-qasm')
plt.plot(us_list[3], zs_list[3], '+', label='1p-ansatz-belem')
plt.plot(uzlist3pnoise[0], uzlist3pnoise[1], 'x', label='3p-ansatz-belem')
plt.ylabel('z')
plt.xlabel('u')
plt.legend()
plt.show()
