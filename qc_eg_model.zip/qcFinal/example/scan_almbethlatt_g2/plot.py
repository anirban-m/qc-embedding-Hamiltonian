import numpy
import matplotlib.pyplot as plt


plt.rcParams["mathtext.fontset"] = "cm"
data = numpy.loadtxt("ecomp.dat").T
fig = plt.figure(figsize=(3, 3))
ax1 = plt.subplot()
ax1.set_xlabel(r'$\epsilon_c$')
ax1.set_ylabel('E')
plt.plot(data[0], data[1], "-s", color="b", label="single-site")
plt.plot(data[0], data[3], "-", color="r")
plt.plot(data[0], data[4], "o", color="r", label="two-site")
plt.legend()

fig.tight_layout()
plt.show()
fig.savefig("ecomp.pdf")

