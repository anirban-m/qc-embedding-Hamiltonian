import numpy, os, h5py, shutil
# from pygrisb.model.almcubic import gutz_model_setup
from pygrisb.model.almbethlattice import gutz_model_setup
from pygrisb.run.cygutz import driver_cygutz, get_cygtail


z_list = []
# eps_c_list = numpy.arange(0.0, 1.4, 0.1)
eps_c_list = [0.7]

with open("z_epsc_1.txt", "w") as frec:
    for eps_c in eps_c_list:
        gutz_model_setup(
                eps_c=eps_c,
                dtype=numpy.float,
                delta=0.01,
                u=2.0,
                iembeddiag=21,
                )
        # mott solution
        # if os.path.isfile("GParam_mott.h5"):
        #     with h5py.File("GParam_mott.h5", "r") as fsrc:
        #         with h5py.File("GParam.h5", "a") as fdst:
        #             fdst.copy(fsrc["/mott"], "/mott")
        driver_cygutz(path=os.environ['WIEN_GUTZ_ROOT'],
                cygtail=get_cygtail(),
                rmethod="hybr",   # 'hybr', "excitingmixing"
                tol=1e-6,
                )
        with h5py.File("GLog.h5", "r") as f:
            r = f["/impurity_0/R"][::2,::2].T
            nelect = f["/"].attrs["nelectrons"]
            emodel = f["/"].attrs["etot_model"]
        with h5py.File("GIter.h5", "r") as f:
            err = f["/v_err"][()]
        maxerr = numpy.max(numpy.abs(err))
        # shutil.copyfile("GLog.h5", f"GLog_{eps_c:.2f}_mott.h5")
        shutil.copyfile("GLog.h5", f"GLog_{eps_c:.2f}.h5")
        z = r.T.conj().dot(r)
        w, v = numpy.linalg.eigh(z)
        frec.write(f"{eps_c:.4f} {emodel:.4f} {nelect:.4f} {w[0]:.4f}" + \
                f" {w[1]:.4f} [{v[0,0]:.3f} {v[1,0]:.3f}] {maxerr:.2e}\n")

