from qiskit.aqua.algorithms import VQE, ExactEigensolver
from qiskit.chemistry import FermionicOperator
from qiskit.chemistry.components.variational_forms import UCCSD
from qiskit.chemistry.components.initial_states import HartreeFock
from qiskit.chemistry.drivers import PySCFDriver, UnitsType
from qiskit.aqua.components.optimizers import SPSA, SLSQP, COBYLA
from qiskit import IBMQ, Aer
from qiskit.providers.aer import noise
from qiskit.aqua import QuantumInstance
from qiskit.ignis.mitigation.measurement import CompleteMeasFitter
from qiskit.aqua.operators.legacy.weighted_pauli_operator import Z2Symmetries
import h5py, numpy
from pyscf import gto


# get the Hamiltonian
driver = PySCFDriver(atom='H .0 .0 -0.3625; H .0 .0 0.3625',
                unit=UnitsType.ANGSTROM, charge=0, spin=0, basis='sto3g')
molecule = driver.run()
num_particles = molecule.num_alpha + molecule.num_beta
num_spin_orbitals = molecule.num_orbitals * 2

v1e = molecule.one_body_integrals
v2e = molecule.two_body_integrals

fermiop = FermionicOperator(h1=v1e, h2=v2e)
qubitOp = fermiop.mapping(map_type='parity')

print("hf energy:", molecule.hf_energy)

# reduce two qubits by symmetry.
qubitOp = Z2Symmetries.two_qubit_reduction(qubitOp, num_particles)
print(qubitOp)

initial_state = HartreeFock(
    num_spin_orbitals,
    num_particles,
    'parity',
    two_qubit_reduction=True,
)
print("initial state:", initial_state.bitstr)

# get qasm uccsd energy.
optimizer = SPSA(maxiter=100)
optimizer = COBYLA(maxiter=100)
var_form = UCCSD(
    num_spin_orbitals,
    num_particles,
    reps=1,
    initial_state=initial_state,
    qubit_mapping='parity',
    two_qubit_reduction=True,
)
print(var_form._single_excitations)
print(var_form._double_excitations)

# for H2
# var_form._hopping_ops = var_form._hopping_ops[2:]
# only one element now
# var_form._hopping_ops[0]._paulis[0][0] *= 2.0
# var_form._hopping_ops[0]._paulis[1][0] = 0.0
# var_form._hopping_ops[0] = var_form._hopping_ops[0].chop()
# var_form._num_parameters = 1
# var_form._bounds = var_form._bounds[2:]

vqe = VQE(qubitOp, var_form, optimizer=optimizer)
print("Number of hopping operators:", var_form._num_parameters)
# statevector_simulator
backend = Aer.get_backend('statevector_simulator')
backend = Aer.get_backend('qasm_simulator')
print(vqe.initial_point)
ret = vqe.run(backend, shots=1000)
print(ret)
