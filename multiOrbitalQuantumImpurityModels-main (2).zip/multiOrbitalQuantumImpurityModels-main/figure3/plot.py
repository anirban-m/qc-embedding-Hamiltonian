import matplotlib.pyplot as plt
import numpy, h5py


eg = -19.18501325
with h5py.File('energies3.h5', 'r') as f:
    energies = f['energies'][()] - eg
    energies_sv = f['energies_sv'][()] - eg
    ticks = f['ticks'][()] - 1                  # zeros-base

data56 = numpy.loadtxt("p56").T
data16 = numpy.loadtxt("p16").T
data10 = numpy.loadtxt("p10").T

fig, axs = plt.subplots(ncols=3, nrows=1, figsize=(8.5, 4.0))
axs[0].set_yscale("log")
axs[0].plot(data56[0], data56[1]-eg, label=f'$N_p = 56$')
axs[0].plot(data16[0], data16[1]-eg, label=f'$N_p = 16$')
axs[0].plot(data10[0], data10[1]-eg, label=f'$N_p = 10$')
axs[0].set_ylim(5.e-6, 5)
axs[0].legend()

xs = list(range(len(energies[0])))
axs[1].plot(xs, energies[0], label=r'$N_p = 56$')
axs[1].plot(xs, energies[1], label=r'$N_p = 16$')
axs[1].plot(xs, energies[2], label=r'$N_p = 10$')
axs[1].axhline(y=0., color='gray', linestyle=':')
axs[1].set_xticks(ticks[1][9::10])
axs[1].set_xticklabels([10, 20, 30, 40])
# axs[1].legend()

xs2 = numpy.array(range(len(energies_sv[0]))) + 1
axs[2].set_yscale("log")
axs[2].plot(xs2, energies_sv[0])
axs[2].plot(xs2, energies_sv[1])
axs[2].plot(xs2, energies_sv[2])
axs[2].set_xticks([10, 20, 30, 40])
axs[2].set_ylim(3e-4, 0.7)

for i, label in enumerate(['(a)', '(b)', '(c)']):
    axs[i].text(0.85, 0.9, label, transform=axs[i].transAxes)

axs[0].set_ylabel(r'$E-E_{GS}$')
axs[0].set_xlabel(r'$N_{\mathbf{\theta}}$')
axs[1].set_xlabel(r'$N_{\mathbf{\theta}}$')
axs[2].set_xlabel(r'$N_{\mathbf{\theta}}$')

axs[0].text(0.1, 0.5, 'state-vector \nsimulation', transform=axs[0].transAxes)
axs[1].text(0.45, 0.7, 'QASM \nsimulation\n'+r'$N_{sh} = 2^{16}$',
        transform=axs[1].transAxes)
axs[2].text(0.1, 0.15, 'state-vector \nanalysis', transform=axs[2].transAxes)


print('err 31:', energies_sv[:, 30])
print('err 40:', energies_sv[:, 39])

plt.tight_layout()
plt.show()
fig.savefig('pools.pdf')
