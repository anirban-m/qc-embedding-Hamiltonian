import h5py, numpy
import matplotlib.pyplot as plt



eg = -19.185013
with h5py.File('energies.h5', 'r') as f:
    energies = f['energies'][()] - eg
    energies_sv = f['energies_sv'][()] - eg
    ticks = f['ticks'][()] - 1                  # zeros-base

xs = list(range(len(energies[0])))
data = numpy.loadtxt('record_m1p1chem_sv.dat').T

import matplotlib as mpl
c1 = mpl.rcParams['axes.prop_cycle']._left[1]['color']
c3 = mpl.rcParams['axes.prop_cycle']._left[3]['color']

fig, axs = plt.subplots(ncols=3, nrows=1, figsize=(8.5, 3.5))
axs[0].plot(xs, energies[1], color=c1, label=r'$N_{sh}=2^{12}$')
axs[0].axhline(y=0., color='gray', linestyle=':')
axs[0].set_xticks(ticks[1][9::10])
axs[0].set_xticklabels([10, 20, 30, 40])

axs[0].set_ylim(-0.04, 0.54)
axs[0].set_ylabel(r'$E-E_{GS}$')
axs[0].set_xlabel(r'$N_{\mathbf{\theta}}$')
axs[0].legend()
axs[1].set_ylim(-0.04, 0.54)
axs[1].set_xlabel(r'$N_{\mathbf{\theta}}$')
axs[2].set_xlabel(r'$N_{\mathbf{\theta}}$')

axs[1].plot(xs, energies[3], color=c3, label=r'$N_{sh}=2^{16}$')
axs[1].axhline(y=0., color='gray', linestyle=':')
axs[1].set_xticks(ticks[3][9::10])
axs[1].set_xticklabels([10, 20, 30, 40])
axs[1].legend()

xs2 = numpy.array(range(len(energies_sv[0]))) + 1
axs[2].set_yscale("log")
labels = [r'$N_{sh}=2^{10}$', None,
        r'$N_{sh}=2^{14}$', None]
for i, ys in enumerate(energies_sv):
    axs[2].plot(xs2, ys, label=labels[i])
axs[2].plot(data[0], data[1]-eg, '--', label=r'$N_{sh}=\infty$')
axs[2].set_xticks([10, 20, 30, 40])
axs[2].legend()
axs[2].set_ylim(1e-4, 0.7)

for i, label in enumerate(['(a)', '(b)', '(c)']):
    axs[i].text(0.12, 0.9, label, transform=axs[i].transAxes)
plt.tight_layout()

plt.show()
fig.savefig('smo.pdf')
