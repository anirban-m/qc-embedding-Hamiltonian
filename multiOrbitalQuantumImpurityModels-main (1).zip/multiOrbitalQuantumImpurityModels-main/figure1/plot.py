import numpy
import matplotlib.pyplot as plt


# exact eg model energy
eb2 = -19.18501325
eb21 = eb2 + 9.778*4
eb3 = -36.46693724
eb31 = eb3 + 12.654938*6

# eg model adapt vqe data
data_b2moavqe = numpy.loadtxt('b2moadapt.dat').T
data_b2hva = numpy.loadtxt('b2hva.dat').T
data_b2com = numpy.loadtxt('b2com.dat').T
data_b2uccsd = numpy.loadtxt('b2uccsd.dat')

data_b3hva = numpy.loadtxt('b3hva.dat').T
data_b3moavqe = numpy.loadtxt('b3mosuccspd.dat').T
data_b3com = numpy.loadtxt('b3aocom.dat').T
data_b3uccsd = numpy.loadtxt('b3uccsd.dat')

err = data_b2uccsd[1]-eb21
print(f'uccsd error: {err:.6f}, {err/eb21*100:.2}%.')
err = data_b3uccsd[1]-eb31
print(f'uccsd error: {err:.6f}, {err/eb31*100:.2}%.')

def plot_result():
    fig, axs = plt.subplots(ncols=2, nrows=2, figsize=(7.5, 6.0))
    axs[0,0].set_yscale("log")
    axs[0,0].set_ylim(1e-6, 5)
    axs[0,0].set_ylabel(r'$E-E_{GS}$')
    axs[0,0].set_xlabel(r'$N_{\mathbf{\theta}}$')
    axs[0,0].text(0.5, 0.85, r'$e_g$ model', transform=axs[0,0].transAxes,
            ha='center')
    axs[0,0].text(0.9, 0.9, '(a)', transform=axs[0,0].transAxes)
    axs[0,1].text(0.9, 0.9, '(b)', transform=axs[0,1].transAxes)
    axs[1,0].text(0.9, 0.9, '(c)', transform=axs[1,0].transAxes)
    axs[1,1].text(0.9, 0.9, '(d)', transform=axs[1,1].transAxes)

    axs[1,0].set_yscale("log")
    axs[1,0].set_ylim(1e-6, 5)
    axs[1,0].set_ylabel(r'$E-E_{GS}$')
    axs[1,0].set_xlabel(r'$N_{cx}$')


    axs[0,1].set_yscale("log")
    axs[0,1].set_ylim(1e-6, 5)
    axs[0,1].set_xlabel(r'$N_{\mathbf{\theta}}$')
    axs[0,1].text(0.5, 0.85, r'$t_{2g}$ model', transform=axs[0, 1].transAxes,
            ha='center')

    axs[1,1].set_yscale("log")
    axs[1,1].set_ylim(1e-6, 5)
    axs[1,1].set_xlabel(r'$N_{cx}$')

    axs[0, 0].plot(data_b2moavqe[0], data_b2moavqe[1]-eb2,
            label='ADAPT-sUCCSpD')
    axs[0, 0].plot(data_b2hva[0], data_b2hva[1]-eb21, 'o--', label='HVA')
    axs[0, 0].plot(data_b2com[0], data_b2com[1]-eb2, label='ADAPT-HC')
    axs[0, 0].scatter(data_b2uccsd[0], data_b2uccsd[1]-eb21, marker='X',
            label='UCCSD')

    axs[1, 0].plot(data_b2moavqe[2], data_b2moavqe[1]-eb2,
            label='ADAPT-sUCCSpD')
    axs[1, 0].plot(data_b2hva[2], data_b2hva[1]-eb21, 'o--', label='HVA')
    axs[1, 0].plot(data_b2com[2], data_b2com[1]-eb2, label='ADAPT-HC')
    axs[1, 0].scatter(data_b2uccsd[2], data_b2uccsd[1]-eb21, marker='X',
            label='UCCSD')
    axs[1, 0].legend()

    axs[0, 1].plot(data_b3moavqe[0], data_b3moavqe[1]-eb3,
            label='ADAPT-sUCCSpD')
    axs[0, 1].plot(data_b3hva[0], data_b3hva[1]-eb31, 'o--', label='HVA')
    axs[0, 1].plot(data_b3com[0], data_b3com[1]-eb3, label='ADAPT-HC')
    axs[0, 1].scatter(data_b3uccsd[0], data_b3uccsd[1]-eb31, marker='X',
            label='UCCSD')

    axs[1, 1].plot(data_b3moavqe[2], data_b3moavqe[1]-eb3)
    axs[1, 1].plot(data_b3hva[2], data_b3hva[1]-eb31, 'o--')
    axs[1, 1].plot(data_b3com[2], data_b3com[1]-eb3, label='ADAPT-HC')
    axs[1, 1].scatter(data_b3uccsd[2], data_b3uccsd[1]-eb31, marker='X')

    plt.tight_layout()
    plt.show()
    fig.savefig("model23.pdf")



if __name__ == "__main__":
    plot_result()
